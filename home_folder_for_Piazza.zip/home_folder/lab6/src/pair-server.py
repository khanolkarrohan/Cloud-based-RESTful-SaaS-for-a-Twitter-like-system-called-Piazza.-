# import the library
import zmq
import time

# Initialize a new context that is the way to create a socket 
context = zmq.Context()

# We will build a PAIR connection

socket = context.socket(zmq.PAIR) # We create a PAIR server

# Do not worry about this for the moment...
socket.setsockopt(zmq.LINGER, 0)

# Create a new socket and "bind" it in the following address 
# Make sure you update the address 
socket.bind("tcp://10.61.64.56:5555") # IP:PORT

# Keep the socket alive for ever...
while True:
    # Send a text message to the client (send_string) 
    socket.send_string("Server message to Client")

    # Receive a message, store it in msg and then print it
    msg = socket.recv()
    print(msg)

    # Sleep for 1 second, so when we run it, we can see the results 
    time.sleep(1)