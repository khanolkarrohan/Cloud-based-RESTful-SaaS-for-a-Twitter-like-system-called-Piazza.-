import sys, zmq
try:
    port1 =  sys.argv[1] # Take port1 from command line
    port2 =  sys.argv[2] # Take port2 from command line
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    print("Collecting updates from weather servers...") 
    socket.connect ("tcp://10.61.64.56:%s" % port1) # UPDATE THE IP! 
    socket.connect ("tcp://10.61.64.56:%s" % port2) # UPDATE THE IP! 
    topicfilter = "10001" # Subscribe to postal code e.g. NYC, 10001
    # Subscribe to topicfilter: 10001, WE CARE ONLY FOR NYC!
    socket.setsockopt_string(zmq.SUBSCRIBE, topicfilter) 
    total_value = 0

    # Lets collect up to 5 subscriptions
    # Then we will calculate the average of 5 temperatures from NYC

    for update_nbr in range (1,5):
        data = socket.recv()
        topic, messagedata,port = data.split() 
        total_value += int(messagedata)
        print("Topic: '%s', message: '%d' on port '%d' "% (topic, int(messagedata), int(port)))
        print("Average messagedata value for topic '%s' was %dF" % (topicfilter, total_value / update_nbr))

except KeyboardInterrupt:
    context.destroy()
    socket.close()