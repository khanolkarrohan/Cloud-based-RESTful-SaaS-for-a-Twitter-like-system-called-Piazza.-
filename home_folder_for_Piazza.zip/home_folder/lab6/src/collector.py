import zmq
import pprint
context = zmq.Context()

# Pull the results from port 5558 (consumers) 
results_receiver = context.socket(zmq.PULL)
results_receiver.bind("tcp://10.61.64.56:5558") # UPDATE THE IP! 
collecter_data = {}
data = {}
asum=0
for x in range(10):
   result = results_receiver.recv_json()
   print(result['num'])
   if result['consumer'] in collecter_data:
       # This is how to count and sum items in a dictionary...
       collecter_data[result['consumer']][0] = collecter_data[result['consumer']][0] + 1
       collecter_data[result['consumer']][1] = collecter_data[result['consumer']][1]+result['num']
   else:
       collecter_data[result['consumer']] = [1, result['num']]
pprint.pprint(collecter_data)