from django.apps import AppConfig


class WebbiderConfig(AppConfig):
    name = 'myapp'
