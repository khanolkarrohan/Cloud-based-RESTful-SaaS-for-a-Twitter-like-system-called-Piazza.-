from rest_framework import serializers
from .models import piazza
class piazzaSerializer(serializers.ModelSerializer): 
    class Meta:
        model = piazza
        fields = ('Title', 'TimeStamp', 'Politics','Description')
