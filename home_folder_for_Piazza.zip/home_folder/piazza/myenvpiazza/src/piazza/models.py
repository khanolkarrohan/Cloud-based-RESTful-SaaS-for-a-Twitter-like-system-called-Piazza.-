from django.db import models
from datetime import datetime
from django.core.validators import MinValueValidator
from django.utils import timezone


# Create your models here.


class piazza(models.Model):
    
    Title = models.CharField(max_length=100)
    Politics = models.BooleanField()
    Health = models.BooleanField()
    Sports = models.BooleanField()
    Tech = models.BooleanField()
    Message_body = models.CharField(max_length=1000)
    Post_ID = models.AutoField(primary_key=True)
    TimeStamp_Post = models.DateTimeField(default=timezone.now)
    ExpDateTime_Post = models.DateTimeField(null=True)
    UserID_Post = models.ForeignKey(User, on_delete=models.CASCADE)
    PostStatus_list = [('Live', 'Live'), ('Expired', 'Expired')]
    Status = models.CharField(
        max_length=100, choices=status_list, default='Live')



class action(models.Model):
    Title = models.OneToOneField(piazza.Title,on_delete=models.CASCADE)
    Message_body = models.OneToOneField(piazza.Message_body,on_delete=models.CASCADE)
    postInteractionID = models.AutoField(primary_key=True)
    userID = models.ForeignKey(User, on_delete=models.CASCADE)
    userName = models.CharField(max_length=60, null=True)
    Post_ID = models.ForeignKey(Post, on_delete=models.CASCADE)
    Action_list = [('Like', 'Like'), ('Dislike', 'Dislike'),
                   ('Comments', 'Comments')]
    Actions = models.CharField(max_length=100, choices=action_list)
    Coment = models.CharField(max_length=600)
    interactionTimeStamp = models.DateTimeField(default=timezone.now)
    







    Owner = settings.AUTH_USER_MODEL
# Create your models here.

class piazza(models.Model):
    Title_of_Post = models.CharField(max_length=100) 
    Politics = models.BooleanField()
    Health = models.BooleanField()
    Sports = models.BooleanField()
    Tech = models.BooleanField()
    Time_Stamp = models.DateTimeField(auto_now_add=True, blank=True)
    #Current_Time = models.DateTimeField(default=timezone.now,blank=True)
    #Expire_Date_Time = model.objects.filter(Current_Time__gte=Current_Time - timedelta(days=7))
    Message_body = models.CharField(max_length=5000)
    Likes = models.ManyToManyField(Owner, related_name='like_user', blank=True)
    Dislike = models.ManyToManyField(Owner, related_name='dislike_user', blank=True)
    Exp_Date = Time_Stamp + timedelta(days=1)
    @property
    def Status(self):
        if(datetime.now() > Exp_Date):
           return 1
         else:
           return 0
    


from piazza import Status

class action(models.Model):
    Post_ID = models.ForeignKey(piazza,on_delete=models.CASCADE, default=None)
    #owner = models.ForeignKey(Owner,on_delete=models.CASCADE)
    status = models.OneToOneField(
        piazza.Status,
        on_delete=models.CASCADE,
    )
    Likes = models.BooleanField()
    Comment = 
    @property
    def LiveExp(self):
        if (status == 0):
            return "Live" 
        else:
            Desible LIKE & COMMENT HERE
            return "Expired" 

class like(model.Models):
    



    
    
