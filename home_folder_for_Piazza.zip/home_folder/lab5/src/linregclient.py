import Pyro4

x, y = [1,2,3,4,5], [5,7,9,11,13]

res = Pyro4.Proxy("PYRONAME:models")

x,y = (res.estimate_coef(x,y))

print(str(x)+"*x + "+str(y))
# print(res.estimate_coef(x,y))