from rest_framework import serializers
from .models import piazza 
from .models import piazza 
from .models import action
from datetime import timedelta, datetime
from django.utils import timezone
from django.conf import settings
from django.contrib.auth.models import User
from django.db.models import Count


class piazzaSerializer(serializers.ModelSerializer): 
    def validate(self, p):
        ExpDateTime_Post = timezone.now() + timedelta(minutes=1000)
        p['ExpDateTime_Post'] = ExpDateTime_Post
        return p
    
    def status_validate(self, s):
        if self.timestamp > self.ExpDateTime_Post:
            status = 'Post Expired'
        s['status'] = status
        return s

    class Meta:
        model = piazza
        fields = ('Title', 'Politics','Health','Sports','Tech','Message_body','Post_ID','TimeStamp_Post','ExpDateTime_Post','UserID_Post','total_likes', 'total_dislikes','total_comments','status1')
        read_only_fields = ('TimeStamp_Post', 'ExpDateTime_Post', 'status1','total_likes', 'total_dislikes','total_comments')
    

class actionSerializer(serializers.ModelSerializer):
    def validate1(self, pt):
        Post_ID = pt['Post_ID'].Post_ID
        Title = piazza.objects.filter(Post_ID=Post_ID).values('Title')
        pt['Title'] = Title[0]['Title']
        return pt

    def validate2(self, interaction):
        userName = interaction['UserID_Post'].username
        interaction['userName'] = userName
        return interaction
    
    def validate_Post_ID(self, p):
        if p.status1 == 'Post_Expired':
            raise serializers.ValidationError({'Post EXPITED ! YOu CANNOT Interact With This Post'})
        return p


    class Meta:
        model = action
        fields = ('postInteractionID','UserID_Post','Post_ID','Actions','comments','interactionTimeStamp')
        read_only_fields = ('postInteractionID', 'interactionTimeStamp')
