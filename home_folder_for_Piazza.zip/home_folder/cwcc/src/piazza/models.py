from django.db import models
from datetime import datetime
from django.core.validators  import MinValueValidator
from django.utils import timezone
from datetime import datetime, timedelta
from django.conf import settings
import random
from datetime import date
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404 

class piazza(models.Model):
    
    Title = models.CharField(max_length=100)
    Politics = models.BooleanField()
    Health = models.BooleanField()
    Sports = models.BooleanField()
    Tech = models.BooleanField()
    Message_body = models.CharField(max_length=1000)
    #Duration_of_Post = models.BigIntegerField()
    Post_ID = models.AutoField(primary_key=True)
    TimeStamp_Post = models.DateTimeField(default=timezone.now)
    ExpDateTime_Post = models.DateTimeField(null=True)
    UserID_Post = models.ForeignKey(User, on_delete=models.CASCADE)
    #PostStatus_list = [('Live', 'Live'), ('Expired', 'Expired')]
    #Status = models.CharField(max_length=100, choices=PostStatus_list, default='Live')
    @property
    def status1(self):
        if timezone.now()>self.ExpDateTime_Post:
            return 'Post_Expired'
        else:
            return 'Post is Live'
    @property
    def total_likes(self):
        return self.relation.filter(Actions='Like').count()
    @property
    def total_dislikes(self):
        return self.relation.filter(Actions='Dislike').count()
    @property
    def total_comments(self):
        return self.relation.exclude(comments='').count() 


    
class action(models.Model):
    postInteractionID = models.AutoField(primary_key=True)
    UserID_Post = models.ForeignKey(User, on_delete=models.CASCADE)
    #userName = models.CharField(max_length=60, null=True)
    Post_ID = models.ForeignKey(piazza, on_delete=models.CASCADE, related_name='relation')
    Action_list = [('',''),('Like', 'Like'), ('Dislike', 'Dislike')]
    Actions = models.CharField(max_length=100, choices=Action_list)
    comments = models.CharField(max_length=600, blank=True)
    interactionTimeStamp = models.DateTimeField(default=timezone.now)
    #status1 = models.OneToOneField(piazza, related_name='status1', verbose_name=('status1'),on_delete=models.CASCADE)
    #Title = models.OneToOneField(piazza, related_name='Title', verbose_name=('Title'),on_delete=models.CASCADE)