from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from .models import piazza
from .models import action
from .serializers import piazzaSerializer 
from .serializers import actionSerializer

class piazzaViewSet(viewsets.ModelViewSet):
    queryset = piazza.objects.all()
    serializer_class = piazzaSerializer

class actionViewSet(viewsets.ModelViewSet):
    queryset = action.objects.all()
    serializer_class = actionSerializer