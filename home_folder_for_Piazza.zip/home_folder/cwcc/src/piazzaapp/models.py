from django.db import models

# Create your models here.

class piazza(models.Model):
    Title_of_Post = models.CharField(max_length=100) 
    Politics = models.BooleanField()
    #Health = models.BooleanField()
    #Sports = models.BooleanField()
    #Tech = models.BooleanField()
    Time_Stamp = models.DateTimeField(auto_now_add=True, blank=True)
    #Expire_Date_Time = models.DateTimeField(default=timezone.now)
    Message_body = models.CharField(max_length=3000)