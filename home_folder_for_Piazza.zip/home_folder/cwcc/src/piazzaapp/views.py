from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from .models import piazza
from .serializers import piazzaSerializer 

class piazzaViewSet(viewsets.ModelViewSet):
    queryset = piazza.objects.all()
    serializer_class = piazzaSerializer

