from rest_framework import serializers
from .models import piazza 
from .models import piazza 
from .models import action
from datetime import timedelta, datetime
from django.utils import timezone
from django.conf import settings
from django.contrib.auth.models import User
from django.db.models import Count


class piazzaSerializer(serializers.ModelSerializer): 
    def validate(self, p): # This validate finction is to create a expiration time for the post.
        ExpDateTime_Post = timezone.now() + timedelta(minutes=5) # timedelta is used in minutes depending on the validaty of post.
        p['ExpDateTime_Post'] = ExpDateTime_Post
        return p
    
    def status_validate(self, s): #This validate functioncompares the timestamo and expiry time and gives the status of the post
        if self.timestamp > self.ExpDateTime_Post:
            status = 'Post Expired'
        s['status'] = status
        return s

    class Meta:
        model = piazza
        fields = ('Title', 'Politics','Health','Sports','Tech','Message_body','Post_ID','TimeStamp_Post','ExpDateTime_Post','UserID_Post','total_likes', 'total_dislikes','total_comments','status1')
        read_only_fields = ('TimeStamp_Post', 'ExpDateTime_Post','Post_ID', 'status1','total_likes', 'total_dislikes','total_comments')
    

class actionSerializer(serializers.ModelSerializer):
    def validate1(self, pt): # This validates the post id and displays the post title in the Post_ID of the form
        Post_ID = pt['Post_ID'].Post_ID
        Title = piazza.objects.filter(Post_ID=Post_ID).values('Title')
        pt['Title'] = Title[0]['Title']
        return pt
    def validate2(self, interaction): # # This validates the user id and displays the user name in the Post_ID of the form
        userName = interaction['UserID_Post'].username
        interaction['userName'] = userName
        return interaction
    
    def validate_Post_ID(self, p): #This validates the if the post is expired from the piazza class validator and restricts action if the post is expired
        if p.status1 == 'Post_Expired':
            raise serializers.ValidationError({'Post EXPITED ! YOu CANNOT Interact With This Post'})
        return p

    
    class Meta:
        model = action
        fields = ('postInteractionID','UserID_Post','Post_ID','Actions','comments','interactionTimeStamp')
        read_only_fields = ('postInteractionID', 'interactionTimeStamp')
    