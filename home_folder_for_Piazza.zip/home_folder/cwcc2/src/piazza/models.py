from django.db import models

# Create your models here.
from datetime import datetime
from django.core.validators  import MinValueValidator
from django.utils import timezone
from datetime import datetime, timedelta
from django.conf import settings
import random
from datetime import date
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404 
from django.core import validators
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

class piazza(models.Model):
    
    Title = models.CharField(max_length=100) # To input characters 
    Politics = models.BooleanField() # True or false (boolean)
    Health = models.BooleanField()# True or false (boolean)
    Sports = models.BooleanField()# True or false (boolean)
    Tech = models.BooleanField()# True or false (boolean)
    Message_body = models.CharField(max_length=1000) # To input characters 
    Post_ID = models.AutoField(primary_key=True) #Creates a post id once the pst is created. This also shares its primary key with other class
    TimeStamp_Post = models.DateTimeField(default=timezone.now) # This give the current timestamp on post created 
    ExpDateTime_Post = models.DateTimeField(null=True) # This is linked with the serilizer validator clause to set the post expiry time
    UserID_Post = models.ForeignKey(User, on_delete=models.CASCADE) # This is a unique USER ID generated and shared with other class via. foreign key
    @property
    def status1(self): # This function compare current time with expiry time and accordignly give the staus.
        if timezone.now()>self.ExpDateTime_Post:
            return 'Post_Expired'
        else:
            return 'Post is Live'
    @property
    def total_likes(self): # This function calls the "Actions" in action and incriment the Like count and display it on the endpoint.
        return self.relation.filter(Actions='Like').count()
    @property
    def total_dislikes(self):# This function calls the "Actions" in action and incriment the Dislike count and display it on the endpoint.
        return self.relation.filter(Actions='Dislike').count()
    @property
    def total_comments(self):# This function calls the "comments" in action and incriment the comments count and display it on the endpoint.
        return self.relation.exclude(comments='').count() 
    
    def __str__(self):  #This displays the post name on the action Post_ID
         return self.Title



class action(models.Model):
    postInteractionID = models.AutoField(primary_key=True) # This takes the primary key from piazza class and creates a unique interaction ID for any interactions.
    UserID_Post = models.ForeignKey(User, on_delete=models.CASCADE) # This is the foreign key for unique user ID , to manitan same numbers in both database.
    Post_ID = models.ForeignKey(piazza, on_delete=models.CASCADE, related_name='relation') #This takes a foreign key to maintain post id from the piazza class
    Action_list = [('',''),('Like', 'Like'), ('Dislike', 'Dislike')] #This is used to create a list of action on the form.
    Actions = models.CharField(max_length=100, choices=Action_list) # After the action is selected it gets stored in this section
    comments = models.CharField(max_length=600, blank=True) #To input characters 
    interactionTimeStamp = models.DateTimeField(default=timezone.now) # This creates a unique timestamp for every interaction
    
    